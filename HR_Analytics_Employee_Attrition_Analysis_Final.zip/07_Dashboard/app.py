# Streamlit App Placeholder
import streamlit as st
st.title('HR Attrition Dashboard')