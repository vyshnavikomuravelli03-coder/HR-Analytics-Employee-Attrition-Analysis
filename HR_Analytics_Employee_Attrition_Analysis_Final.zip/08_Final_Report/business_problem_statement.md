# Business Problem Statement
Employee attrition analysis across 1,470 synthetic records.