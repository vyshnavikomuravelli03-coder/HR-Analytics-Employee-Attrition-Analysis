# HR Analytics & Employee Attrition Analysis

## Project Overview
An end-to-end data analytics, SQL diagnostics, statistical hypothesis testing, and interactive dashboard project investigating workforce turnover drivers using the **IBM HR Analytics Employee Attrition & Performance** dataset.

### Important Dataset Disclaimer & Limitations
- **Synthetic Data Origin:** This dataset (1,470 employee records, 35 features) is a **fictional/synthetic dataset** created by IBM data scientists for educational and analytical modeling—not real corporate HR records.
- **No Calendar Dates:** The dataset contains no hire-date or exit-date timestamps; therefore, no monthly or yearly time-series attrition trends are fabricated.
- **Unspecified Currency:** Income fields (`MonthlyIncome`, `DailyRate`, `HourlyRate`, `MonthlyRate`) do not specify a currency unit and are reported as plain numeric values without `$` or `₹` symbols.
- **Sharing Terms:** Before redistributing the raw Kaggle CSV publicly, verify Kaggle's current dataset license and sharing terms on the official dataset page.

## Key Findings Summary
- **Baseline Attrition:** **16.12%** (237 departures out of 1,470 employees; 83.88% retention).
- **Overtime Association:** Overtime workers leave at **30.53%** vs. **10.44%** for non-overtime staff ($\chi^2 = 87.56, p < 0.0001$).
- **High-Risk Roles:** **Sales Representatives** (**39.76%** attrition) and **Laboratory Technicians** (**23.94%** attrition) exhibit the highest turnover concentrations.
- **Early Tenure Risk:** Employees in their first **0–1 years** experience **34.88%** attrition, accounting for nearly one-third of all departures.
- **Compensation Gap:** Attrited employees average **4,787.09 units/month** vs. **6,832.74 units/month** for retained peers ($p < 0.0001$).

## Folder Structure
```text
HR_Analytics_Employee_Attrition_Analysis/
├── 01_Dataset/              # Original CSV, cleaned CSV, and 35-column data dictionary
├── 02_Data_Cleaning/        # Data cleaning notebook, quality report, before/after summary
├── 03_EDA/                  # EDA notebook, 10+ PNG/HTML visualizations, KPI summary
├── 04_SQL_Analysis/         # SQLite database (.db), SQL queries (.sql), query results
├── 05_Statistical_Analysis/ # Hypothesis testing notebook, test results, confidence intervals
├── 06_Machine_Learning/     # Educational classification models, ROC/CM charts, ethics doc
├── 07_Dashboard/            # Streamlit app (app.py), screenshots, Excel report (.xlsx)
├── 08_Final_Report/         # Final PDF project report & strategic HR recommendations
└── 09_GitHub/               # Repository link, project README, source scripts
```

## Ethical Considerations
Predictive classification models (Logistic Regression, Decision Tree, Random Forest) included in this project are strictly for **educational and aggregate workforce diagnostics**. Model outputs must never be used to make employment decisions about individual employees.
