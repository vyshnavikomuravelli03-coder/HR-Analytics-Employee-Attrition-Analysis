-- SQL queries for Attrition Analysis
SELECT * FROM hr_employees;