# Task 5: Statistical Analysis, Predictive Modeling & Ethical Considerations Report

## Part A: Hypothesis Testing & Statistical Analysis

### 1. Overtime vs. Employee Attrition (Chi-Square Test of Independence)
- **Hypotheses:**
  - $H_0$: Employee overtime status (`OverTime`) and attrition (`Attrition`) are independent.
  - $H_1$: Employee overtime status and attrition are statistically associated.
- **Methodology:** 2x2 Contingency Table analyzed via Pearson's Chi-Square test ($\chi^2$) with Yates' continuity correction.
- **Key Findings:** Overtime workers experience an attrition rate of **30.53%** (127/416) compared to **10.44%** (110/1,054) among non-overtime staff ($\chi^2 = 87.56, p < 0.0001$). We reject $H_0$: workload intensity via overtime has a highly significant association with employee turnover.

### 2. Job Satisfaction Differences: Retained vs. Attrited (Mann-Whitney U & Welch's T-Test)
- **Methodology:** Because `JobSatisfaction` is an ordinal Likert scale (`1` to `4`), we apply the non-parametric **Mann-Whitney U test** alongside Welch's two-sample t-test.
- **Key Findings:** Employees who leave report lower mean job satisfaction (**2.47**) than those who stay (**2.78**), with $p < 0.0001$. Lower job satisfaction is a statistically significant differentiator between departing and retained cohorts.

### 3. Monthly Income Disparities & Confidence Intervals (Welch's T-Test, Mann-Whitney U & 95% CI)
- **Methodology:** Two-sample Welch's t-test, non-parametric Mann-Whitney U test (accounting for right-skewed executive salaries), and 95% Confidence Intervals around group means.
- **Key Findings:**
  - **Retained Employees (`No`):** Mean Monthly Income = **6,832.74 units** (95% CI: `[6,563.10, 7,102.38]`)
  - **Attrited Employees (`Yes`):** Mean Monthly Income = **4,787.09 units** (95% CI: `[4,321.85, 5,252.33]`)
  - The difference of **2,045.65 units** is statistically significant ($p < 0.0001$) with non-overlapping 95% confidence intervals. *(Note: Currency symbol omitted per dataset specifications.)*

### 4. Department-Level Attrition Significance (Chi-Square Contingency Test)
- **Methodology:** 3x2 Chi-Square test across `Sales`, `Research & Development`, and `Human Resources`.
- **Key Findings:** Turnover rates differ significantly across departments ($\chi^2 = 10.79, p = 0.0045$), led by **Sales (20.63%)** and **Human Resources (19.05%)** versus **Research & Development (13.84%)**.

---

## Part B: Machine Learning Extension (Educational Classification Exercise)

### 1. Experimental Setup
- **Preprocessing:** One-hot encoding for nominal categoricals, `StandardScaler` for numeric features, stratified 80/20 train-test split (`1,176` train / `294` test records) preserving the 16.12% minority class ratio.
- **Class Imbalance Handling:** Applied `class_weight='balanced'` so models prioritize detecting minority-class leavers (`Attrition = Yes`) rather than defaulting to majority-class predictions.
- **Models Evaluated:**
  1. **Logistic Regression** (interpretable linear baseline)
  2. **Decision Tree Classifier** (`max_depth=5` to prevent overfitting)
  3. **Random Forest Classifier** (`n_estimators=200`, `max_depth=8`)

### 2. Why Recall for Leavers (`Attrition = Yes`) Is Prioritized
In HR retention analytics, a **False Negative** (predicting an at-risk employee segment will stay when they actually leave) costs the organization institutional knowledge, recruiting expense, and onboarding ramp-up time. Conversely, a **False Positive** simply extends supportive retention programs (mentorship, workload review, career pathing) to a stable cohort. Therefore, **Recall (Sensitivity)** and **ROC-AUC** are prioritized alongside F1-score.

---

## Part C: Model Limitations & Ethical Considerations (Mandatory Governance)

1. **Strictly Educational & Aggregate Use Only:**
   - These models are built strictly for **educational demonstration and macro-level organizational insight** (identifying systemic risk factors like overtime overload or entry-level pay gaps).
   - **Prohibition on Individual Decisions:** Predictive scores must **NEVER** be used to hire, fire, demote, deny promotions, or penalize individual employees.
2. **Synthetic & Cross-Sectional Data Limitations:**
   - The IBM HR dataset consists of **1,470 fictional records** without longitudinal hire/exit timestamps or documented currency units. Patterns learned here reflect synthetic data generation rules rather than real-world causal laws.
3. **Algorithmic Bias & Fairness Risks:**
   - Variables such as `Age`, `Gender`, `MaritalStatus`, and `DistanceFromHome` can introduce proxy discrimination if used in automated HR tooling. Responsible HR analytics restricts interventions to **structural workplace improvements** (reducing excessive overtime, improving manager training, benchmarking entry-level compensation).
4. **Correlation Is Not Causation:**
   - Statistical significance and feature importance highlight associations, not guaranteed root causes. HR leadership should validate insights through confidential employee pulse surveys and exit interviews before enacting policy changes.
