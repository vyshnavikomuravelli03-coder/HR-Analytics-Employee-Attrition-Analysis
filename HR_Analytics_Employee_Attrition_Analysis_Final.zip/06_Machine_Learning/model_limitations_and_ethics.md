# Model Limitations & Ethics
Models are strictly for educational and aggregate use.