# Data Cleaning Documentation
Zero missing values, constant columns dropped.