# Key Findings
Sales and OverTime represent key turnover risk factors.